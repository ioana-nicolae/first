# frozen_string_literal: true

RSpec.configure do |config|
  config.silence_filter_announcements = true
end
